# Vigilante App Icons & Assets Guide

## Generated Assets

### Base App Icon (1024x1024)
![App Icon](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052392791_0d503bec.png)

**Download:** [app-icon-base-1024.png](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052392791_0d503bec.png)

Save this to `public/app-icon-base-1024.png` before running the icon generator.

---

### Open Graph Image (1200x630)
![OG Image](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052416016_2729dadc.png)

**Download:** [og-image.png](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052416016_2729dadc.png)

Save this to `public/og-image.png` — used for social sharing previews on Facebook, LinkedIn, Twitter, Slack, Discord, etc.

---

### App Store Screenshots

| Feature | Preview | Download |
|---------|---------|----------|
| **Dashboard** | ![Dashboard](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052448996_ed712b04.jpg) | [dashboard.jpg](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052448996_ed712b04.jpg) |
| **Scam Checker** | ![Scam Checker](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052469663_34e92698.png) | [scam-checker.png](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052469663_34e92698.png) |
| **Email Guardian** | ![Email Guardian](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052594720_855d9fbc.jpg) | [email-guardian.jpg](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052594720_855d9fbc.jpg) |
| **SMS Guardian** | ![SMS Guardian](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052620432_fcf34f02.png) | [sms-guardian.png](https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052620432_fcf34f02.png) |

Save these to `public/screenshots/` directory.

---

## Quick Setup

### Step 1: Download Base Assets

```bash
# Create directories
mkdir -p public/icons/ios public/icons/android public/icons/pwa public/icons/social public/screenshots

# Download base icon (1024x1024)
curl -o public/app-icon-base-1024.png "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052392791_0d503bec.png"

# Download OG image
curl -o public/og-image.png "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052416016_2729dadc.png"

# Download screenshots
curl -o public/screenshots/dashboard.jpg "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052448996_ed712b04.jpg"
curl -o public/screenshots/scam-checker.png "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052469663_34e92698.png"
curl -o public/screenshots/email-guardian.jpg "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052594720_855d9fbc.jpg"
curl -o public/screenshots/sms-guardian.png "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052620432_fcf34f02.png"
```

### Step 2: Generate All Icon Sizes

```bash
# Install sharp (image processing library)
npm install sharp --save-dev

# Run the icon generator
node scripts/generate-icons.js
```

### Step 3: Verify Output

After running the generator, you'll have:

```
public/
├── app-icon-base-1024.png          # Source icon
├── apple-touch-icon.png            # 180x180 (iOS Safari)
├── favicon.svg                     # Vector favicon (already exists)
├── favicon-16x16.png               # Browser tab
├── favicon-32x32.png               # Browser tab
├── icon-48x48.png                  # PWA
├── icon-72x72.png                  # PWA
├── icon-96x96.png                  # PWA
├── icon-128x128.png                # PWA
├── icon-144x144.png                # PWA
├── icon-152x152.png                # PWA
├── icon-167x167.png                # iPad Pro
├── icon-180x180.png                # iPhone (same as apple-touch-icon)
├── icon-192x192.png                # PWA / Android
├── icon-256x256.png                # PWA
├── icon-384x384.png                # PWA
├── icon-512x512.png                # PWA / Android
├── og-image.png                    # Social sharing (1200x630)
├── manifest.json                   # References all icons
│
├── icons/
│   ├── ios/
│   │   ├── Contents.json                  # Xcode asset catalog
│   │   ├── ios-icon-20.png                # 20x20 (iPad notification)
│   │   ├── ios-icon-20@2x.png             # 40x40 (iPhone notification)
│   │   ├── ios-icon-20@2x-ipad.png        # 40x40 (iPad notification @2x)
│   │   ├── ios-icon-20@3x.png             # 60x60 (iPhone notification @3x)
│   │   ├── ios-icon-29.png                # 29x29 (iPad settings)
│   │   ├── ios-icon-29@2x.png             # 58x58 (iPhone settings)
│   │   ├── ios-icon-29@2x-ipad.png        # 58x58 (iPad settings @2x)
│   │   ├── ios-icon-29@3x.png             # 87x87 (iPhone settings @3x)
│   │   ├── ios-icon-40.png                # 40x40 (iPad spotlight)
│   │   ├── ios-icon-40@2x.png             # 80x80 (iPhone spotlight)
│   │   ├── ios-icon-40@2x-ipad.png        # 80x80 (iPad spotlight @2x)
│   │   ├── ios-icon-40@3x.png             # 120x120 (iPhone spotlight @3x)
│   │   ├── ios-icon-60@2x.png             # 120x120 (iPhone app)
│   │   ├── ios-icon-60@3x.png             # 180x180 (iPhone app @3x)
│   │   ├── ios-icon-76.png                # 76x76 (iPad app)
│   │   ├── ios-icon-76@2x.png             # 152x152 (iPad app @2x)
│   │   ├── ios-icon-83.5@2x.png           # 167x167 (iPad Pro app)
│   │   └── ios-icon-1024.png              # 1024x1024 (App Store - NO transparency)
│   │
│   ├── android/
│   │   ├── android-icon-mdpi-48.png       # 48x48 (mdpi launcher)
│   │   ├── android-icon-hdpi-72.png       # 72x72 (hdpi launcher)
│   │   ├── android-icon-xhdpi-96.png      # 96x96 (xhdpi launcher)
│   │   ├── android-icon-xxhdpi-144.png    # 144x144 (xxhdpi launcher)
│   │   ├── android-icon-xxxhdpi-192.png   # 192x192 (xxxhdpi launcher)
│   │   ├── android-adaptive-mdpi-108.png  # 108x108 (adaptive foreground)
│   │   ├── android-adaptive-hdpi-162.png  # 162x162 (adaptive foreground)
│   │   ├── android-adaptive-xhdpi-216.png # 216x216 (adaptive foreground)
│   │   ├── android-adaptive-xxhdpi-324.png# 324x324 (adaptive foreground)
│   │   ├── android-adaptive-xxxhdpi-432.png# 432x432 (adaptive foreground)
│   │   └── android-playstore-512.png      # 512x512 (Play Store listing)
│   │
│   ├── pwa/
│   │   ├── icon-192x192-maskable.png      # Maskable (safe zone padding)
│   │   ├── icon-512x512-maskable.png      # Maskable (safe zone padding)
│   │   └── ... (all PWA sizes)
│   │
│   └── social/
│       └── (reserved for future social assets)
│
└── screenshots/
    ├── dashboard.jpg                      # Dashboard feature screenshot
    ├── scam-checker.png                   # Scam Checker feature screenshot
    ├── email-guardian.jpg                 # Email Guardian feature screenshot
    └── sms-guardian.png                   # SMS Guardian feature screenshot
```

---

## Complete Icon Size Reference

### iOS App Store (Apple)

| Context | Size | Scale | Pixels | File |
|---------|------|-------|--------|------|
| iPhone Notification | 20pt | @2x | 40x40 | `ios-icon-20@2x.png` |
| iPhone Notification | 20pt | @3x | 60x60 | `ios-icon-20@3x.png` |
| iPhone Settings | 29pt | @2x | 58x58 | `ios-icon-29@2x.png` |
| iPhone Settings | 29pt | @3x | 87x87 | `ios-icon-29@3x.png` |
| iPhone Spotlight | 40pt | @2x | 80x80 | `ios-icon-40@2x.png` |
| iPhone Spotlight | 40pt | @3x | 120x120 | `ios-icon-40@3x.png` |
| iPhone App | 60pt | @2x | 120x120 | `ios-icon-60@2x.png` |
| iPhone App | 60pt | @3x | 180x180 | `ios-icon-60@3x.png` |
| iPad Notification | 20pt | @1x | 20x20 | `ios-icon-20.png` |
| iPad Notification | 20pt | @2x | 40x40 | `ios-icon-20@2x-ipad.png` |
| iPad Settings | 29pt | @1x | 29x29 | `ios-icon-29.png` |
| iPad Settings | 29pt | @2x | 58x58 | `ios-icon-29@2x-ipad.png` |
| iPad Spotlight | 40pt | @1x | 40x40 | `ios-icon-40.png` |
| iPad Spotlight | 40pt | @2x | 80x80 | `ios-icon-40@2x-ipad.png` |
| iPad App | 76pt | @1x | 76x76 | `ios-icon-76.png` |
| iPad App | 76pt | @2x | 152x152 | `ios-icon-76@2x.png` |
| iPad Pro App | 83.5pt | @2x | 167x167 | `ios-icon-83.5@2x.png` |
| **App Store** | **1024pt** | **@1x** | **1024x1024** | **`ios-icon-1024.png`** |

> **Important:** The 1024x1024 App Store icon MUST NOT have transparency (alpha channel). The generator flattens it with a `#4c1d95` background.

### Google Play Store (Android)

| Density | Launcher | Adaptive Foreground | File |
|---------|----------|-------------------|------|
| mdpi | 48x48 | 108x108 | `android-icon-mdpi-*.png` |
| hdpi | 72x72 | 162x162 | `android-icon-hdpi-*.png` |
| xhdpi | 96x96 | 216x216 | `android-icon-xhdpi-*.png` |
| xxhdpi | 144x144 | 324x324 | `android-icon-xxhdpi-*.png` |
| xxxhdpi | 192x192 | 432x432 | `android-icon-xxxhdpi-*.png` |
| **Play Store** | **512x512** | — | **`android-playstore-512.png`** |

### PWA / Web Manifest

| Size | Purpose | Usage |
|------|---------|-------|
| 16x16 | `any` | Browser favicon |
| 32x32 | `any` | Browser favicon (HiDPI) |
| 48x48 | `any` | Windows taskbar |
| 72x72 | `any` | PWA |
| 96x96 | `any` | PWA |
| 128x128 | `any` | Chrome Web Store |
| 144x144 | `any` | PWA / Windows tiles |
| 152x152 | `any` | iPad touch icon |
| 167x167 | `any` | iPad Pro touch icon |
| 180x180 | `any` | iPhone touch icon |
| 192x192 | `any` + `maskable` | Android Chrome |
| 256x256 | `any` | PWA |
| 384x384 | `any` | PWA |
| 512x512 | `any` + `maskable` | PWA splash screen |

### Social Media

| Platform | Size | File |
|----------|------|------|
| Facebook / LinkedIn / Slack | 1200x630 | `og-image.png` |
| Twitter Card | 1200x600 | `twitter-card.png` |
| Instagram / Square | 1080x1080 | `social-square.png` |

---

## Copying Icons to Native Projects

### iOS (Xcode)

After generating icons, copy the entire `ios/` folder contents into your Xcode project:

```bash
# After running: npx cap add ios
cp -r public/icons/ios/* ios/App/App/Assets.xcassets/AppIcon.appiconset/
```

The `Contents.json` file is auto-generated and maps each icon to the correct slot in Xcode.

### Android (Capacitor)

```bash
# After running: npx cap add android

# Standard launcher icons
cp public/icons/android/android-icon-mdpi-48.png android/app/src/main/res/mipmap-mdpi/ic_launcher.png
cp public/icons/android/android-icon-hdpi-72.png android/app/src/main/res/mipmap-hdpi/ic_launcher.png
cp public/icons/android/android-icon-xhdpi-96.png android/app/src/main/res/mipmap-xhdpi/ic_launcher.png
cp public/icons/android/android-icon-xxhdpi-144.png android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png
cp public/icons/android/android-icon-xxxhdpi-192.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png

# Round launcher icons (same files)
cp public/icons/android/android-icon-mdpi-48.png android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png
cp public/icons/android/android-icon-hdpi-72.png android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png
cp public/icons/android/android-icon-xhdpi-96.png android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png
cp public/icons/android/android-icon-xxhdpi-144.png android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png
cp public/icons/android/android-icon-xxxhdpi-192.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png

# Adaptive icon foreground
cp public/icons/android/android-adaptive-mdpi-108.png android/app/src/main/res/mipmap-mdpi/ic_launcher_foreground.png
cp public/icons/android/android-adaptive-hdpi-162.png android/app/src/main/res/mipmap-hdpi/ic_launcher_foreground.png
cp public/icons/android/android-adaptive-xhdpi-216.png android/app/src/main/res/mipmap-xhdpi/ic_launcher_foreground.png
cp public/icons/android/android-adaptive-xxhdpi-324.png android/app/src/main/res/mipmap-xxhdpi/ic_launcher_foreground.png
cp public/icons/android/android-adaptive-xxxhdpi-432.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png
```

---

## App Store Screenshot Specifications

### Apple App Store

| Device | Size (Portrait) | Required |
|--------|-----------------|----------|
| iPhone 6.7" (15 Pro Max) | 1290 x 2796 | Yes |
| iPhone 6.5" (14 Plus) | 1284 x 2778 | Yes |
| iPhone 5.5" (8 Plus) | 1242 x 2208 | Optional |
| iPad Pro 12.9" | 2048 x 2732 | If supporting iPad |
| iPad Pro 11" | 1668 x 2388 | If supporting iPad |

### Google Play Store

| Type | Size | Required |
|------|------|----------|
| Phone screenshots | 1080 x 1920 (min) | Yes (2-8) |
| 7" Tablet | 1200 x 1920 | Optional |
| 10" Tablet | 1600 x 2560 | Optional |
| Feature Graphic | 1024 x 500 | Yes |
| Hi-res Icon | 512 x 512 | Yes |

---

## Troubleshooting

### "sharp" not found
```bash
npm install sharp --save-dev
# On M1/M2 Mac, you may need:
npm install --platform=darwin --arch=arm64 sharp
```

### iOS icon has white background instead of purple
The generator flattens the 1024x1024 icon with `#4c1d95` background. If you need a different background, edit `scripts/generate-icons.js` and change the `background` value.

### Icons look blurry on Android
Make sure you're using the adaptive icon foreground files (`android-adaptive-*.png`) which include proper padding for the safe zone. Android's adaptive icon system crops the outer edges.

### Maskable icons look zoomed in
This is intentional — maskable icons have 10% padding on each side so the content stays within the "safe zone" when the OS applies different mask shapes (circle, squircle, etc.).
