#!/usr/bin/env node

/**
 * Vigilante App Icon Generator
 * 
 * Generates all required icon sizes for:
 * - Apple App Store (iOS)
 * - Google Play Store (Android)
 * - PWA (Web Manifest)
 * - Favicons (Browser)
 * - Social Media (OG Image)
 * 
 * Prerequisites:
 *   npm install sharp
 * 
 * Usage:
 *   node scripts/generate-icons.js
 * 
 * Input:  public/app-icon-base-1024.png (1024x1024)
 * Output: public/icons/ directory with all sizes
 */

const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

// ============================================================
// CONFIGURATION
// ============================================================

const BASE_ICON = path.join(__dirname, '..', 'public', 'app-icon-base-1024.png');
const OUTPUT_DIR = path.join(__dirname, '..', 'public', 'icons');
const ROOT_OUTPUT = path.join(__dirname, '..', 'public');

// ============================================================
// iOS APP STORE ICON SIZES
// Required for Xcode Asset Catalog (AppIcon.appiconset)
// ============================================================
const IOS_ICONS = [
  // iPhone Notification (iOS 7-17)
  { size: 20, scale: 2, filename: 'ios-icon-20@2x.png' },
  { size: 20, scale: 3, filename: 'ios-icon-20@3x.png' },
  
  // iPhone Settings (iOS 7-17)
  { size: 29, scale: 2, filename: 'ios-icon-29@2x.png' },
  { size: 29, scale: 3, filename: 'ios-icon-29@3x.png' },
  
  // iPhone Spotlight (iOS 7-17)
  { size: 40, scale: 2, filename: 'ios-icon-40@2x.png' },
  { size: 40, scale: 3, filename: 'ios-icon-40@3x.png' },
  
  // iPhone App (iOS 7-17)
  { size: 60, scale: 2, filename: 'ios-icon-60@2x.png' },
  { size: 60, scale: 3, filename: 'ios-icon-60@3x.png' },
  
  // iPad Notification (iOS 7-17)
  { size: 20, scale: 1, filename: 'ios-icon-20.png' },
  { size: 20, scale: 2, filename: 'ios-icon-20@2x-ipad.png' },
  
  // iPad Settings (iOS 7-17)
  { size: 29, scale: 1, filename: 'ios-icon-29.png' },
  { size: 29, scale: 2, filename: 'ios-icon-29@2x-ipad.png' },
  
  // iPad Spotlight (iOS 7-17)
  { size: 40, scale: 1, filename: 'ios-icon-40.png' },
  { size: 40, scale: 2, filename: 'ios-icon-40@2x-ipad.png' },
  
  // iPad App (iOS 7-17)
  { size: 76, scale: 1, filename: 'ios-icon-76.png' },
  { size: 76, scale: 2, filename: 'ios-icon-76@2x.png' },
  
  // iPad Pro App (iOS 9-17)
  { size: 83.5, scale: 2, filename: 'ios-icon-83.5@2x.png' },
  
  // App Store (required - 1024x1024, NO alpha/transparency)
  { size: 1024, scale: 1, filename: 'ios-icon-1024.png' },
];

// ============================================================
// ANDROID / GOOGLE PLAY STORE ICON SIZES
// ============================================================
const ANDROID_ICONS = [
  // Launcher icons (mipmap directories)
  { size: 48, density: 'mdpi', filename: 'android-icon-mdpi-48.png' },
  { size: 72, density: 'hdpi', filename: 'android-icon-hdpi-72.png' },
  { size: 96, density: 'xhdpi', filename: 'android-icon-xhdpi-96.png' },
  { size: 144, density: 'xxhdpi', filename: 'android-icon-xxhdpi-144.png' },
  { size: 192, density: 'xxxhdpi', filename: 'android-icon-xxxhdpi-192.png' },
  
  // Adaptive icon foreground (with padding for safe zone)
  { size: 108, density: 'mdpi', filename: 'android-adaptive-mdpi-108.png', adaptive: true },
  { size: 162, density: 'hdpi', filename: 'android-adaptive-hdpi-162.png', adaptive: true },
  { size: 216, density: 'xhdpi', filename: 'android-adaptive-xhdpi-216.png', adaptive: true },
  { size: 324, density: 'xxhdpi', filename: 'android-adaptive-xxhdpi-324.png', adaptive: true },
  { size: 432, density: 'xxxhdpi', filename: 'android-adaptive-xxxhdpi-432.png', adaptive: true },
  
  // Google Play Store (512x512, required)
  { size: 512, density: 'playstore', filename: 'android-playstore-512.png' },
];

// ============================================================
// PWA / WEB MANIFEST ICON SIZES
// ============================================================
const PWA_ICONS = [
  { size: 16, filename: 'favicon-16x16.png' },
  { size: 32, filename: 'favicon-32x32.png' },
  { size: 48, filename: 'icon-48x48.png' },
  { size: 72, filename: 'icon-72x72.png' },
  { size: 96, filename: 'icon-96x96.png' },
  { size: 128, filename: 'icon-128x128.png' },
  { size: 144, filename: 'icon-144x144.png' },
  { size: 152, filename: 'icon-152x152.png' },
  { size: 167, filename: 'icon-167x167.png' },
  { size: 180, filename: 'icon-180x180.png' },   // apple-touch-icon
  { size: 192, filename: 'icon-192x192.png' },
  { size: 256, filename: 'icon-256x256.png' },
  { size: 384, filename: 'icon-384x384.png' },
  { size: 512, filename: 'icon-512x512.png' },
];

// ============================================================
// MASKABLE ICONS (with safe zone padding)
// For PWA "maskable" purpose - icon content in center 80%
// ============================================================
const MASKABLE_ICONS = [
  { size: 192, filename: 'icon-192x192-maskable.png' },
  { size: 512, filename: 'icon-512x512-maskable.png' },
];

// ============================================================
// SOCIAL MEDIA / OG IMAGES
// ============================================================
const SOCIAL_IMAGES = [
  { width: 1200, height: 630, filename: 'og-image.png', description: 'Open Graph (Facebook, LinkedIn)' },
  { width: 1200, height: 600, filename: 'twitter-card.png', description: 'Twitter Card' },
  { width: 1080, height: 1080, filename: 'social-square.png', description: 'Instagram / Social Square' },
];

// ============================================================
// GENERATION FUNCTIONS
// ============================================================

async function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`  Created directory: ${dir}`);
  }
}

async function generateIcon(inputPath, outputPath, width, height, options = {}) {
  const { flatten = true, background = '#4c1d95', padding = 0 } = options;
  
  try {
    let pipeline = sharp(inputPath);
    
    if (flatten) {
      // Remove alpha channel (required for iOS App Store 1024x1024)
      pipeline = pipeline.flatten({ background });
    }
    
    if (padding > 0) {
      // For adaptive/maskable icons, resize smaller and add padding
      const innerSize = Math.round(width * (1 - padding * 2));
      pipeline = pipeline
        .resize(innerSize, innerSize || height, { fit: 'contain', background })
        .extend({
          top: Math.round(width * padding),
          bottom: Math.round(width * padding),
          left: Math.round(width * padding),
          right: Math.round(width * padding),
          background,
        });
    } else {
      pipeline = pipeline.resize(width, height || width, { fit: 'contain', background });
    }
    
    await pipeline.png({ quality: 100, compressionLevel: 9 }).toFile(outputPath);
    return true;
  } catch (err) {
    console.error(`  ERROR generating ${outputPath}: ${err.message}`);
    return false;
  }
}

async function generateAllIcons() {
  console.log('\n========================================');
  console.log('  VIGILANTE APP ICON GENERATOR');
  console.log('========================================\n');
  
  // Check for base icon
  if (!fs.existsSync(BASE_ICON)) {
    console.error(`\n  ERROR: Base icon not found at ${BASE_ICON}`);
    console.error('  Please save your 1024x1024 base icon as:');
    console.error('    public/app-icon-base-1024.png\n');
    console.error('  You can download it from:');
    console.error('    https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052392791_0d503bec.png\n');
    process.exit(1);
  }
  
  // Ensure output directories
  await ensureDir(OUTPUT_DIR);
  await ensureDir(path.join(OUTPUT_DIR, 'ios'));
  await ensureDir(path.join(OUTPUT_DIR, 'android'));
  await ensureDir(path.join(OUTPUT_DIR, 'pwa'));
  await ensureDir(path.join(OUTPUT_DIR, 'social'));
  
  let generated = 0;
  let failed = 0;
  
  // ---- iOS Icons ----
  console.log('  [iOS] Generating App Store icons...');
  for (const icon of IOS_ICONS) {
    const pixelSize = Math.round(icon.size * icon.scale);
    const outputPath = path.join(OUTPUT_DIR, 'ios', icon.filename);
    const flatten = icon.size === 1024; // App Store icon MUST have no transparency
    const success = await generateIcon(BASE_ICON, outputPath, pixelSize, pixelSize, { flatten });
    if (success) {
      console.log(`    ✓ ${icon.filename} (${pixelSize}x${pixelSize})`);
      generated++;
    } else {
      failed++;
    }
  }
  
  // ---- Android Icons ----
  console.log('\n  [Android] Generating Play Store icons...');
  for (const icon of ANDROID_ICONS) {
    const outputPath = path.join(OUTPUT_DIR, 'android', icon.filename);
    const options = icon.adaptive ? { padding: 0.1, background: '#4c1d95' } : {};
    const success = await generateIcon(BASE_ICON, outputPath, icon.size, icon.size, options);
    if (success) {
      console.log(`    ✓ ${icon.filename} (${icon.size}x${icon.size} - ${icon.density})`);
      generated++;
    } else {
      failed++;
    }
  }
  
  // ---- PWA Icons ----
  console.log('\n  [PWA] Generating web manifest icons...');
  for (const icon of PWA_ICONS) {
    // Output to both /icons/pwa/ and root /public/ for direct access
    const outputPath = path.join(OUTPUT_DIR, 'pwa', icon.filename);
    const rootPath = path.join(ROOT_OUTPUT, icon.filename);
    
    const success = await generateIcon(BASE_ICON, outputPath, icon.size, icon.size);
    if (success) {
      // Also copy to root public directory
      fs.copyFileSync(outputPath, rootPath);
      console.log(`    ✓ ${icon.filename} (${icon.size}x${icon.size})`);
      generated++;
    } else {
      failed++;
    }
  }
  
  // ---- Maskable Icons ----
  console.log('\n  [Maskable] Generating maskable PWA icons...');
  for (const icon of MASKABLE_ICONS) {
    const outputPath = path.join(OUTPUT_DIR, 'pwa', icon.filename);
    const success = await generateIcon(BASE_ICON, outputPath, icon.size, icon.size, { padding: 0.1, background: '#4c1d95' });
    if (success) {
      console.log(`    ✓ ${icon.filename} (${icon.size}x${icon.size})`);
      generated++;
    } else {
      failed++;
    }
  }
  
  // ---- Apple Touch Icon (special) ----
  console.log('\n  [Apple] Generating apple-touch-icon...');
  const appleTouchPath = path.join(ROOT_OUTPUT, 'apple-touch-icon.png');
  const success = await generateIcon(BASE_ICON, appleTouchPath, 180, 180);
  if (success) {
    console.log('    ✓ apple-touch-icon.png (180x180)');
    generated++;
  } else {
    failed++;
  }
  
  // ---- Summary ----
  console.log('\n========================================');
  console.log(`  COMPLETE: ${generated} icons generated, ${failed} failed`);
  console.log('========================================');
  console.log(`\n  Output directory: ${OUTPUT_DIR}`);
  console.log('  Root favicons:   public/');
  console.log('\n  Next steps:');
  console.log('  1. Copy ios/ icons to Xcode AppIcon.appiconset');
  console.log('  2. Copy android/ icons to android/app/src/main/res/mipmap-*');
  console.log('  3. PWA icons are already in public/ for web manifest');
  console.log('  4. Run: npx cap sync\n');
}

// ============================================================
// XCODE CONTENTS.JSON GENERATOR
// ============================================================
function generateXcodeContentsJson() {
  const contents = {
    images: IOS_ICONS.map(icon => ({
      filename: icon.filename,
      idiom: icon.size >= 76 ? 'ipad' : 'iphone',
      scale: `${icon.scale}x`,
      size: `${icon.size}x${icon.size}`,
      ...(icon.size === 1024 ? { idiom: 'ios-marketing' } : {}),
    })),
    info: {
      author: 'vigilante-icon-generator',
      version: 1,
    },
  };
  
  const outputPath = path.join(OUTPUT_DIR, 'ios', 'Contents.json');
  fs.writeFileSync(outputPath, JSON.stringify(contents, null, 2));
  console.log('\n  [Xcode] Generated Contents.json for AppIcon.appiconset');
}

// ============================================================
// RUN
// ============================================================
generateAllIcons()
  .then(() => generateXcodeContentsJson())
  .catch(err => {
    console.error('Fatal error:', err);
    process.exit(1);
  });
