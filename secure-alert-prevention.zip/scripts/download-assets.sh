#!/bin/bash

# ============================================================
# Vigilante Asset Downloader
# Downloads all generated assets to the correct directories
# 
# Usage: bash scripts/download-assets.sh
# ============================================================

set -e

echo ""
echo "========================================"
echo "  VIGILANTE ASSET DOWNLOADER"
echo "========================================"
echo ""

# Create directories
echo "  Creating directories..."
mkdir -p public/icons/ios
mkdir -p public/icons/android
mkdir -p public/icons/pwa
mkdir -p public/icons/social
mkdir -p public/screenshots

# ---- Base App Icon (1024x1024) ----
echo ""
echo "  [1/6] Downloading base app icon (1024x1024)..."
curl -sL -o public/app-icon-base-1024.png \
  "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052392791_0d503bec.png"
echo "    ✓ public/app-icon-base-1024.png"

# ---- OG Image (1200x630) ----
echo ""
echo "  [2/6] Downloading OG image (1200x630)..."
curl -sL -o public/og-image.png \
  "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052416016_2729dadc.png"
echo "    ✓ public/og-image.png"

# ---- Screenshot: Dashboard ----
echo ""
echo "  [3/6] Downloading screenshot: Dashboard..."
curl -sL -o public/screenshots/dashboard.jpg \
  "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052448996_ed712b04.jpg"
echo "    ✓ public/screenshots/dashboard.jpg"

# ---- Screenshot: Scam Checker ----
echo ""
echo "  [4/6] Downloading screenshot: Scam Checker..."
curl -sL -o public/screenshots/scam-checker.png \
  "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052469663_34e92698.png"
echo "    ✓ public/screenshots/scam-checker.png"

# ---- Screenshot: Email Guardian ----
echo ""
echo "  [5/6] Downloading screenshot: Email Guardian..."
curl -sL -o public/screenshots/email-guardian.jpg \
  "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052594720_855d9fbc.jpg"
echo "    ✓ public/screenshots/email-guardian.jpg"

# ---- Screenshot: SMS Guardian ----
echo ""
echo "  [6/6] Downloading screenshot: SMS Guardian..."
curl -sL -o public/screenshots/sms-guardian.png \
  "https://d64gsuwffb70l.cloudfront.net/69c9dd6f2ee6b4cc3ffecc79_1776052620432_fcf34f02.png"
echo "    ✓ public/screenshots/sms-guardian.png"

echo ""
echo "========================================"
echo "  ALL ASSETS DOWNLOADED SUCCESSFULLY"
echo "========================================"
echo ""
echo "  Next steps:"
echo "  1. Install sharp:  npm install sharp --save-dev"
echo "  2. Generate icons:  npm run generate-icons"
echo "  3. Build & deploy:  npm run build"
echo ""
