import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

export type SubscriptionTier = 'free' | 'pro' | 'family';
export type BillingInterval = 'monthly' | 'annual';

interface SubscriptionRecord {
  tier: SubscriptionTier;
  billing_interval: BillingInterval;
  status: string;
  stripe_customer_id?: string | null;
  stripe_subscription_id?: string | null;
  current_period_end?: string | null;
}

interface SubscriptionContextType {
  tier: SubscriptionTier;
  billingInterval: BillingInterval;
  status: string;
  isPro: boolean;
  isFamily: boolean;
  isPaid: boolean;
  isLoading: boolean;
  hasFeature: (feature: PremiumFeature) => boolean;
  setLocalSubscription: (rec: Partial<SubscriptionRecord>) => Promise<void>;
  refreshSubscription: () => Promise<void>;
}

export type PremiumFeature =
  | 'email-guardian'
  | 'sms-guardian'
  | 'call-guardian'
  | 'child-shield'
  | 'weekly-reports'
  | 'priority-alerts'
  | 'family-members';

// Which feature is gated to which minimum tier
const FEATURE_REQUIREMENTS: Record<PremiumFeature, SubscriptionTier> = {
  'email-guardian': 'pro',
  'sms-guardian': 'pro',
  'call-guardian': 'pro',
  'weekly-reports': 'pro',
  'child-shield': 'family',
  'priority-alerts': 'family',
  'family-members': 'family',
};

const TIER_RANK: Record<SubscriptionTier, number> = {
  free: 0,
  pro: 1,
  family: 2,
};

const SubscriptionContext = createContext<SubscriptionContextType>({
  tier: 'free',
  billingInterval: 'monthly',
  status: 'inactive',
  isPro: false,
  isFamily: false,
  isPaid: false,
  isLoading: false,
  hasFeature: () => false,
  setLocalSubscription: async () => {},
  refreshSubscription: async () => {},
});

export const useSubscription = () => useContext(SubscriptionContext);

const LOCAL_KEY = 'vigilante.subscription';

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [record, setRecord] = useState<SubscriptionRecord>({
    tier: 'free',
    billing_interval: 'monthly',
    status: 'inactive',
  });
  const [isLoading, setIsLoading] = useState(false);

  // Load from localStorage on mount (works for guests too)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(LOCAL_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.tier) setRecord((r) => ({ ...r, ...parsed }));
      }
    } catch {}
  }, []);

  const fetchFromDb = useCallback(async (userId: string) => {
    try {
      setIsLoading(true);
      const { data } = await supabase
        .from('user_subscriptions')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();
      if (data) {
        const rec: SubscriptionRecord = {
          tier: (data.tier as SubscriptionTier) || 'free',
          billing_interval: (data.billing_interval as BillingInterval) || 'monthly',
          status: data.status || 'inactive',
          stripe_customer_id: data.stripe_customer_id,
          stripe_subscription_id: data.stripe_subscription_id,
          current_period_end: data.current_period_end,
        };
        setRecord(rec);
        try {
          localStorage.setItem(LOCAL_KEY, JSON.stringify(rec));
        } catch {}
      }
    } catch (err) {
      console.error('Subscription fetch error', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user?.id) {
      fetchFromDb(user.id);
    }
  }, [user?.id, fetchFromDb]);

  const setLocalSubscription = useCallback(
    async (partial: Partial<SubscriptionRecord>) => {
      const next: SubscriptionRecord = { ...record, ...partial } as SubscriptionRecord;
      setRecord(next);
      try {
        localStorage.setItem(LOCAL_KEY, JSON.stringify(next));
      } catch {}
      if (user?.id) {
        try {
          await supabase
            .from('user_subscriptions')
            .upsert(
              {
                user_id: user.id,
                tier: next.tier,
                billing_interval: next.billing_interval,
                status: next.status,
                stripe_customer_id: next.stripe_customer_id,
                stripe_subscription_id: next.stripe_subscription_id,
                current_period_end: next.current_period_end,
                updated_at: new Date().toISOString(),
              },
              { onConflict: 'user_id' }
            );
        } catch (err) {
          console.error('Subscription save error', err);
        }
      }
    },
    [record, user?.id]
  );

  const refreshSubscription = useCallback(async () => {
    if (user?.id) await fetchFromDb(user.id);
  }, [user?.id, fetchFromDb]);

  const hasFeature = useCallback(
    (feature: PremiumFeature) => {
      const required = FEATURE_REQUIREMENTS[feature];
      return TIER_RANK[record.tier] >= TIER_RANK[required];
    },
    [record.tier]
  );

  const isPaid = record.tier !== 'free' && record.status === 'active';

  return (
    <SubscriptionContext.Provider
      value={{
        tier: record.tier,
        billingInterval: record.billing_interval,
        status: record.status,
        isPro: record.tier === 'pro' && record.status === 'active',
        isFamily: record.tier === 'family' && record.status === 'active',
        isPaid,
        isLoading,
        hasFeature,
        setLocalSubscription,
        refreshSubscription,
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
};
