import React, { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, ArrowLeft, ShieldCheck, Lock, RefreshCw, Headphones } from 'lucide-react';
import { useSubscription, BillingInterval } from '@/contexts/SubscriptionContext';
import { useAuth } from '@/contexts/AuthContext';
import PricingTierCard, { PRICING_TIERS, PricingTier } from '@/components/pricing/PricingTierCard';
import PricingComparisonTable from '@/components/pricing/PricingComparisonTable';
import CheckoutModal from '@/components/pricing/CheckoutModal';

const FAQS: { q: string; a: string }[] = [
  {
    q: 'Can I cancel anytime?',
    a: 'Yes — there are no contracts. Cancel from your profile and you keep access through the end of your current billing period.',
  },
  {
    q: "What's the difference between Pro and Family?",
    a: 'Pro covers one person and protects their email, SMS, and calls. Family adds Child Shield (predator detection), supports up to 6 members, and includes a shared family dashboard.',
  },
  {
    q: 'Do I need a credit card for the Free plan?',
    a: 'No. Free is forever free, no card required. Upgrade only when you want active monitoring.',
  },
  {
    q: 'Is my payment secure?',
    a: 'Payments are processed by Stripe, a PCI-DSS Level 1 provider. We never see or store your card details.',
  },
  {
    q: 'Can I switch between monthly and annual?',
    a: 'Absolutely. Switch billing intervals anytime from your profile — the next charge prorates automatically.',
  },
  {
    q: 'How does the 20% annual discount work?',
    a: 'Pay yearly and save the equivalent of about 2.4 months. The annual price is shown right above each plan.',
  },
];

const Pricing: React.FC = () => {
  const navigate = useNavigate();
  const { tier: currentTier } = useSubscription();
  const { openAuthModal } = useAuth();
  const [billingInterval, setBillingInterval] = useState<BillingInterval>('monthly');
  const [checkoutTier, setCheckoutTier] = useState<PricingTier | null>(null);

  const handleSelect = useCallback(
    (t: PricingTier) => {
      if (t.key === 'free') {
        openAuthModal('signup');
        return;
      }
      setCheckoutTier(t);
    },
    [openAuthModal]
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-violet-50 via-white to-white">
      {/* Top bar */}
      <header className="bg-white border-b-2 border-violet-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <div className="bg-gradient-to-br from-violet-900 to-purple-800 p-2 rounded-xl">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-violet-900">The Vigilante</span>
          </button>
          <button
            onClick={() => navigate('/')}
            className="flex items-center gap-1 text-violet-700 hover:text-violet-900 font-semibold text-sm"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to home
          </button>
        </div>
      </header>

      {/* Hero */}
      <section className="px-4 sm:px-6 lg:px-8 pt-16 pb-10 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-100 text-violet-700 text-xs font-bold uppercase tracking-wide mb-5">
            <ShieldCheck className="w-3.5 h-3.5" />
            Simple, family-friendly pricing
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 leading-tight">
            Protection that fits{' '}
            <span className="bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
              every household
            </span>
          </h1>
          <p className="mt-5 text-lg text-gray-600 max-w-2xl mx-auto">
            Start free with AI scam checking. Upgrade to Pro for active monitoring across email, SMS, and calls — or pick Family for full-household protection with Child Shield.
          </p>

          {/* Billing toggle */}
          <div className="mt-10 inline-flex items-center bg-white rounded-full p-1.5 border-2 border-violet-200 shadow-sm">
            <button
              onClick={() => setBillingInterval('monthly')}
              className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all ${
                billingInterval === 'monthly'
                  ? 'bg-violet-900 text-white shadow'
                  : 'text-gray-600 hover:text-violet-900'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingInterval('annual')}
              className={`px-6 py-2.5 rounded-full text-sm font-bold transition-all flex items-center gap-2 ${
                billingInterval === 'annual'
                  ? 'bg-violet-900 text-white shadow'
                  : 'text-gray-600 hover:text-violet-900'
              }`}
            >
              Annual
              <span
                className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                  billingInterval === 'annual'
                    ? 'bg-emerald-400 text-emerald-900'
                    : 'bg-emerald-100 text-emerald-700'
                }`}
              >
                SAVE 20%
              </span>
            </button>
          </div>
        </div>
      </section>

      {/* Tier cards */}
      <section className="px-4 sm:px-6 lg:px-8 pb-16">
        <div className="max-w-7xl mx-auto grid md:grid-cols-3 gap-6 lg:gap-8 items-stretch">
          {PRICING_TIERS.map((t) => (
            <PricingTierCard
              key={t.key}
              tier={t}
              billingInterval={billingInterval}
              currentTier={currentTier}
              onSelect={handleSelect}
            />
          ))}
        </div>
      </section>

      {/* Trust badges */}
      <section className="px-4 sm:px-6 lg:px-8 pb-16">
        <div className="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[
            { icon: <Lock className="w-6 h-6" />, label: 'Stripe-secured payments' },
            { icon: <RefreshCw className="w-6 h-6" />, label: 'Cancel anytime' },
            { icon: <ShieldCheck className="w-6 h-6" />, label: '30-day money-back' },
            { icon: <Headphones className="w-6 h-6" />, label: 'Real human support' },
          ].map((b) => (
            <div key={b.label} className="bg-white rounded-2xl border border-gray-200 p-5 flex flex-col items-center gap-2">
              <div className="w-12 h-12 rounded-xl bg-violet-100 text-violet-700 flex items-center justify-center">
                {b.icon}
              </div>
              <p className="text-sm font-semibold text-gray-700">{b.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Comparison table */}
      <section className="px-4 sm:px-6 lg:px-8 pb-20">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">Compare every feature</h2>
            <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
              See exactly what's included in each plan side-by-side.
            </p>
          </div>
          <PricingComparisonTable />
        </div>
      </section>

      {/* FAQ */}
      <section className="px-4 sm:px-6 lg:px-8 pb-24 bg-gradient-to-b from-white to-violet-50/40">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">Frequently asked questions</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-5">
            {FAQS.map((f) => (
              <div key={f.q} className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
                <h3 className="font-bold text-gray-900 mb-2">{f.q}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{f.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="px-4 sm:px-6 lg:px-8 pb-24">
        <div className="max-w-4xl mx-auto rounded-3xl bg-gradient-to-r from-violet-700 via-purple-700 to-pink-700 text-white p-10 sm:p-14 text-center shadow-2xl">
          <h2 className="text-3xl sm:text-4xl font-bold">Ready to protect what matters most?</h2>
          <p className="mt-3 text-violet-100 text-lg">
            Join thousands of families using The Vigilante to stay one step ahead of scammers.
          </p>
          <button
            onClick={() => handleSelect(PRICING_TIERS[1])}
            className="mt-7 px-8 py-4 rounded-xl bg-white text-violet-900 font-bold text-lg hover:bg-violet-50 shadow-lg"
          >
            Start Pro for $4.99/mo
          </button>
        </div>
      </section>

      <CheckoutModal
        open={!!checkoutTier}
        onClose={() => setCheckoutTier(null)}
        tier={checkoutTier}
        billingInterval={billingInterval}
      />
    </div>
  );
};

export default Pricing;
