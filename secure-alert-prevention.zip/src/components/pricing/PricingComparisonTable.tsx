import React from 'react';
import { Check, X, Minus } from 'lucide-react';

interface FeatureRow {
  category: string;
  rows: { label: string; free: boolean | string; pro: boolean | string; family: boolean | string }[];
}

const FEATURE_GROUPS: FeatureRow[] = [
  {
    category: 'AI Scam Detection',
    rows: [
      { label: 'AI scam checker (paste & analyze)', free: '5/day', pro: 'Unlimited', family: 'Unlimited' },
      { label: 'Phishing & smishing detection', free: true, pro: true, family: true },
      { label: 'Confidence scoring & explanations', free: true, pro: true, family: true },
      { label: 'Scam check history', free: '7 days', pro: '1 year', family: 'Unlimited' },
    ],
  },
  {
    category: 'Active Monitoring',
    rows: [
      { label: 'Email Vigilante (auto inbox scan)', free: false, pro: true, family: true },
      { label: 'SMS Vigilante (text scam detection)', free: false, pro: true, family: true },
      { label: 'Call Vigilante (caller risk scoring)', free: false, pro: true, family: true },
      { label: 'Weekly protection reports', free: false, pro: true, family: true },
    ],
  },
  {
    category: 'Family Protection',
    rows: [
      { label: 'Child Shield (predator detection)', free: false, pro: false, family: true },
      { label: 'Family member accounts', free: '1', pro: '1', family: 'Up to 6' },
      { label: 'Shared family dashboard', free: false, pro: false, family: true },
      { label: 'Device Shield (per-device monitoring)', free: 'Limited', pro: '1 device', family: 'Unlimited' },
    ],
  },
  {
    category: 'Community & Alerts',
    rows: [
      { label: 'Community scam map', free: true, pro: true, family: true },
      { label: 'Local scam alerts', free: true, pro: true, family: true },
      { label: 'Real-time priority alerts', free: false, pro: false, family: true },
      { label: 'Report scams to community', free: true, pro: true, family: true },
    ],
  },
  {
    category: 'Support',
    rows: [
      { label: 'Help center & resources', free: true, pro: true, family: true },
      { label: 'Email support', free: '48hr', pro: 'Priority', family: 'Priority' },
      { label: 'Phone & chat support', free: false, pro: false, family: true },
    ],
  },
];

const renderCell = (val: boolean | string) => {
  if (val === true)
    return (
      <span className="inline-flex w-7 h-7 items-center justify-center rounded-full bg-emerald-100">
        <Check className="w-4 h-4 text-emerald-700" strokeWidth={3} />
      </span>
    );
  if (val === false)
    return (
      <span className="inline-flex w-7 h-7 items-center justify-center rounded-full bg-gray-100">
        <X className="w-4 h-4 text-gray-400" strokeWidth={2.5} />
      </span>
    );
  return <span className="text-sm font-semibold text-gray-900">{val}</span>;
};

const PricingComparisonTable: React.FC = () => {
  return (
    <div className="overflow-x-auto rounded-3xl border border-gray-200 bg-white shadow-lg">
      <table className="w-full min-w-[720px]">
        <thead>
          <tr className="bg-gradient-to-r from-violet-50 to-purple-50 border-b-2 border-violet-200">
            <th className="text-left py-5 px-6 text-base font-bold text-gray-900 w-2/5">Feature</th>
            <th className="text-center py-5 px-4 text-base font-bold text-gray-700">Free</th>
            <th className="text-center py-5 px-4 text-base font-bold text-violet-700 bg-violet-100/60">
              Pro
            </th>
            <th className="text-center py-5 px-4 text-base font-bold text-pink-700">Family</th>
          </tr>
        </thead>
        <tbody>
          {FEATURE_GROUPS.map((group) => (
            <React.Fragment key={group.category}>
              <tr className="bg-gray-50">
                <td colSpan={4} className="py-3 px-6 text-sm font-bold text-gray-700 uppercase tracking-wide">
                  {group.category}
                </td>
              </tr>
              {group.rows.map((row) => (
                <tr key={row.label} className="border-b border-gray-100 hover:bg-violet-50/30 transition-colors">
                  <td className="py-4 px-6 text-sm text-gray-800">{row.label}</td>
                  <td className="py-4 px-4 text-center">{renderCell(row.free)}</td>
                  <td className="py-4 px-4 text-center bg-violet-50/40">{renderCell(row.pro)}</td>
                  <td className="py-4 px-4 text-center">{renderCell(row.family)}</td>
                </tr>
              ))}
            </React.Fragment>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PricingComparisonTable;
