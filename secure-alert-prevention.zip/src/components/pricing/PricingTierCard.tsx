import React from 'react';
import { Check, Sparkles, Shield, Users, Star } from 'lucide-react';
import { SubscriptionTier, BillingInterval } from '@/contexts/SubscriptionContext';

export interface PricingTier {
  key: 'free' | 'pro' | 'family';
  name: string;
  tagline: string;
  monthlyPrice: number; // dollars
  annualPrice: number; // dollars total per year
  features: string[];
  highlighted?: boolean;
  ctaLabel: string;
  icon: React.ReactNode;
  accentClass: string; // gradient classes
  borderClass: string;
}

interface Props {
  tier: PricingTier;
  billingInterval: BillingInterval;
  currentTier: SubscriptionTier;
  onSelect: (tier: PricingTier) => void;
}

const PricingTierCard: React.FC<Props> = ({ tier, billingInterval, currentTier, onSelect }) => {
  const isCurrent = currentTier === tier.key;
  const monthlyDisplay =
    tier.monthlyPrice === 0
      ? 0
      : billingInterval === 'monthly'
      ? tier.monthlyPrice
      : +(tier.annualPrice / 12).toFixed(2);
  const totalAnnual = tier.annualPrice;

  return (
    <div
      className={`relative rounded-3xl bg-white shadow-xl p-8 flex flex-col ${tier.borderClass} ${
        tier.highlighted ? 'ring-4 ring-violet-300 scale-105 lg:scale-100 lg:translate-y-[-8px]' : ''
      } transition-all`}
    >
      {tier.highlighted && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-violet-600 to-purple-600 text-white text-sm font-bold px-4 py-1.5 rounded-full shadow-lg flex items-center gap-1">
          <Star className="w-4 h-4 fill-white" />
          MOST POPULAR
        </div>
      )}

      <div className={`inline-flex w-14 h-14 items-center justify-center rounded-2xl ${tier.accentClass} text-white mb-4`}>
        {tier.icon}
      </div>

      <h3 className="text-2xl font-bold text-gray-900">{tier.name}</h3>
      <p className="text-gray-600 mt-1 mb-6 min-h-[48px]">{tier.tagline}</p>

      <div className="mb-6">
        <div className="flex items-baseline gap-1">
          <span className="text-5xl font-extrabold text-gray-900">
            ${monthlyDisplay}
          </span>
          {tier.monthlyPrice > 0 && (
            <span className="text-gray-500 font-medium">/mo</span>
          )}
        </div>
        {tier.monthlyPrice > 0 && billingInterval === 'annual' && (
          <p className="text-sm text-emerald-700 font-semibold mt-1">
            Billed ${totalAnnual.toFixed(2)}/yr · Save 20%
          </p>
        )}
        {tier.monthlyPrice > 0 && billingInterval === 'monthly' && (
          <p className="text-sm text-gray-500 mt-1">Billed monthly · Cancel anytime</p>
        )}
        {tier.monthlyPrice === 0 && (
          <p className="text-sm text-gray-500 mt-1">Forever free · No card required</p>
        )}
      </div>

      <ul className="space-y-3 mb-8 flex-1">
        {tier.features.map((feat, idx) => (
          <li key={idx} className="flex items-start gap-3 text-gray-700">
            <span className={`flex-shrink-0 mt-0.5 w-5 h-5 rounded-full ${tier.accentClass} flex items-center justify-center`}>
              <Check className="w-3 h-3 text-white" strokeWidth={3} />
            </span>
            <span className="text-sm leading-snug">{feat}</span>
          </li>
        ))}
      </ul>

      <button
        onClick={() => onSelect(tier)}
        disabled={isCurrent}
        className={`w-full py-3.5 rounded-xl font-bold text-base transition-all ${
          isCurrent
            ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
            : tier.highlighted
            ? 'bg-gradient-to-r from-violet-600 to-purple-600 text-white hover:from-violet-700 hover:to-purple-700 shadow-lg hover:shadow-xl'
            : tier.key === 'free'
            ? 'bg-gray-900 text-white hover:bg-gray-800'
            : 'bg-violet-100 text-violet-900 hover:bg-violet-200 border-2 border-violet-200'
        }`}
      >
        {isCurrent ? 'Current Plan' : tier.ctaLabel}
      </button>
    </div>
  );
};

export const PRICING_TIERS: PricingTier[] = [
  {
    key: 'free',
    name: 'Free',
    tagline: 'Essential scam protection for everyone.',
    monthlyPrice: 0,
    annualPrice: 0,
    icon: <Shield className="w-7 h-7" />,
    accentClass: 'bg-gradient-to-br from-gray-700 to-gray-900',
    borderClass: 'border border-gray-200',
    ctaLabel: 'Get Started Free',
    features: [
      '5 AI scam checks per day',
      'Community scam map access',
      'Scam alerts & quick tips',
      'Report a scam to the community',
      'Resource library access',
    ],
  },
  {
    key: 'pro',
    name: 'Pro',
    tagline: 'Active monitoring for you across email, SMS, and calls.',
    monthlyPrice: 4.99,
    annualPrice: 47.88,
    icon: <Sparkles className="w-7 h-7" />,
    accentClass: 'bg-gradient-to-br from-violet-600 to-purple-700',
    borderClass: 'border-2 border-violet-300',
    ctaLabel: 'Start Pro',
    highlighted: true,
    features: [
      'Everything in Free',
      'Unlimited AI scam checks',
      'Email Vigilante — auto-scan inbox',
      'SMS Vigilante — text scam detection',
      'Call Vigilante — caller risk scoring',
      'Weekly protection reports',
      'Priority email support',
    ],
  },
  {
    key: 'family',
    name: 'Family',
    tagline: 'Full-household protection with Child Shield and shared alerts.',
    monthlyPrice: 15.99,
    annualPrice: 153.48,
    icon: <Users className="w-7 h-7" />,
    accentClass: 'bg-gradient-to-br from-pink-600 to-rose-700',
    borderClass: 'border-2 border-pink-300',
    ctaLabel: 'Start Family',
    features: [
      'Everything in Pro',
      'Up to 6 family members',
      'Child Shield — predator detection',
      'Device Shield for every device',
      'Real-time priority scam alerts',
      'Shared family scam dashboard',
      'Dedicated phone & chat support',
    ],
  },
];

export default PricingTierCard;
