import React, { useEffect, useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { X, Lock, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useSubscription, BillingInterval } from '@/contexts/SubscriptionContext';
import { PricingTier } from './PricingTierCard';

const STRIPE_ACCOUNT_ID = 'acct_1TMAbaHixNloaQ16';
const STRIPE_PK =
  'pk_live_51OJhJBHdGQpsHqInIzu7c6PzGPSH0yImD4xfpofvxvFZs0VFhPRXZCyEgYkkhOtBOXFWvssYASs851mflwQvjnrl00T6DbUwWZ';
const stripePromise = loadStripe(STRIPE_PK, { stripeAccount: STRIPE_ACCOUNT_ID });

interface CheckoutModalProps {
  open: boolean;
  onClose: () => void;
  tier: PricingTier | null;
  billingInterval: BillingInterval;
}

const buildPlanKey = (tierKey: 'pro' | 'family' | 'free', interval: BillingInterval) =>
  `${tierKey}-${interval}` as 'pro-monthly' | 'pro-annual' | 'family-monthly' | 'family-annual';

const PaymentForm: React.FC<{
  customerId: string;
  planKey: string;
  tierKey: 'pro' | 'family';
  billingInterval: BillingInterval;
  onSuccess: () => void;
  onCancel: () => void;
}> = ({ customerId, planKey, tierKey, billingInterval, onSuccess, onCancel }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { setLocalSubscription } = useSubscription();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setLoading(true);
    setError(null);

    try {
      const { error: setupErr, setupIntent } = await stripe.confirmSetup({
        elements,
        confirmParams: { return_url: window.location.origin + '/pricing?success=1' },
        redirect: 'if_required',
      });

      if (setupErr) {
        setError(setupErr.message || 'Payment setup failed');
        setLoading(false);
        return;
      }

      if (setupIntent?.status === 'succeeded') {
        const { data, error: fnErr } = await supabase.functions.invoke('create-subscription', {
          body: {
            action: 'activate-subscription',
            customerId,
            paymentMethodId: setupIntent.payment_method,
            planKey,
          },
        });

        if (fnErr || data?.error) {
          setError(data?.error || fnErr?.message || 'Could not activate subscription');
          setLoading(false);
          return;
        }

        await setLocalSubscription({
          tier: tierKey,
          billing_interval: billingInterval,
          status: 'active',
          stripe_customer_id: customerId,
          stripe_subscription_id: data.subscriptionId,
        });

        onSuccess();
      }
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement options={{ layout: 'tabs' }} />
      {error && (
        <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-800">
          <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}
      <div className="flex items-center gap-2 text-xs text-gray-500">
        <Lock className="w-3 h-3" />
        <span>Secure payment by Stripe · Cancel anytime from your profile</span>
      </div>
      <div className="flex gap-3 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-3 rounded-xl border-2 border-gray-200 text-gray-700 font-semibold hover:bg-gray-50"
          disabled={loading}
        >
          Back
        </button>
        <button
          type="submit"
          disabled={!stripe || loading}
          className="flex-1 px-4 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-bold hover:from-violet-700 hover:to-purple-700 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
          {loading ? 'Processing…' : 'Subscribe'}
        </button>
      </div>
    </form>
  );
};

const CheckoutModal: React.FC<CheckoutModalProps> = ({ open, onClose, tier, billingInterval }) => {
  const { user, openAuthModal } = useAuth();
  const [step, setStep] = useState<'email' | 'payment' | 'success'>('email');
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [customerId, setCustomerId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setStep('email');
      setError(null);
      setClientSecret(null);
      setCustomerId(null);
      if (user?.email) setEmail(user.email);
    }
  }, [open, user?.email]);

  if (!open || !tier || tier.key === 'free') return null;

  const planKey = buildPlanKey(tier.key, billingInterval);
  const monthlyEquivalent =
    billingInterval === 'monthly' ? tier.monthlyPrice : +(tier.annualPrice / 12).toFixed(2);
  const totalChargeNow =
    billingInterval === 'monthly' ? tier.monthlyPrice : tier.annualPrice;

  const handleStartCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    setError(null);

    try {
      // Subscribe to CRM first (this is an email collection)
      try {
        await fetch('https://famous.ai/api/crm/69c9dd6f2ee6b4cc3ffecc79/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            email,
            name: name || undefined,
            source: 'checkout',
            tags: ['checkout', `plan-${tier.key}`, `billing-${billingInterval}`],
          }),
        });
      } catch {
        /* non-blocking */
      }

      const { data, error: fnErr } = await supabase.functions.invoke('create-subscription', {
        body: {
          action: 'create-setup-intent',
          email,
          name,
          planKey,
        },
      });

      if (fnErr || data?.error) {
        throw new Error(data?.error || fnErr?.message || 'Could not start checkout');
      }

      setClientSecret(data.clientSecret);
      setCustomerId(data.customerId);
      setStep('payment');
    } catch (err: any) {
      setError(err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-gray-100 z-10"
          aria-label="Close"
        >
          <X className="w-5 h-5 text-gray-600" />
        </button>

        <div className={`px-7 pt-7 pb-5 ${tier.accentClass} text-white`}>
          <p className="text-sm font-semibold opacity-90 uppercase tracking-wide">
            Subscribe to Vigilante {tier.name}
          </p>
          <h3 className="text-3xl font-bold mt-2">
            ${monthlyEquivalent}
            <span className="text-base font-medium opacity-90">/mo</span>
          </h3>
          <p className="text-sm opacity-90 mt-1">
            {billingInterval === 'annual'
              ? `Charged $${totalChargeNow.toFixed(2)} today, then yearly. Save 20%.`
              : `Charged $${totalChargeNow.toFixed(2)} today, then monthly.`}
          </p>
        </div>

        <div className="p-7">
          {step === 'email' && (
            <form onSubmit={handleStartCheckout} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Email address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-violet-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  Full name <span className="text-gray-400 font-normal">(optional)</span>
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Jane Doe"
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-violet-500 focus:outline-none"
                />
              </div>
              {!user && (
                <div className="text-xs text-gray-600 bg-violet-50 border border-violet-200 rounded-lg p-3">
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      openAuthModal('login');
                    }}
                    className="text-violet-700 font-semibold underline"
                  >
                    Sign in
                  </button>{' '}
                  to link your subscription.
                </div>
              )}
              {error && (
                <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-800">
                  <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              <button
                type="submit"
                disabled={loading || !email}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-bold hover:from-violet-700 hover:to-purple-700 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
                {loading ? 'Loading…' : 'Continue to Payment'}
              </button>
            </form>
          )}

          {step === 'payment' && clientSecret && customerId && (
            <Elements
              stripe={stripePromise}
              options={{ clientSecret, appearance: { theme: 'stripe' } }}
            >
              <PaymentForm
                customerId={customerId}
                planKey={planKey}
                tierKey={tier.key as 'pro' | 'family'}
                billingInterval={billingInterval}
                onSuccess={() => setStep('success')}
                onCancel={() => setStep('email')}
              />
            </Elements>
          )}

          {step === 'success' && (
            <div className="text-center py-6">
              <div className="inline-flex w-16 h-16 items-center justify-center rounded-full bg-emerald-100 mb-4">
                <CheckCircle2 className="w-9 h-9 text-emerald-600" />
              </div>
              <h4 className="text-2xl font-bold text-gray-900">Welcome to {tier.name}!</h4>
              <p className="text-gray-600 mt-2">
                Your subscription is active. Premium features are now unlocked.
              </p>
              <button
                onClick={onClose}
                className="mt-6 px-6 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-bold hover:from-violet-700 hover:to-purple-700"
              >
                Start using Vigilante {tier.name}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;
