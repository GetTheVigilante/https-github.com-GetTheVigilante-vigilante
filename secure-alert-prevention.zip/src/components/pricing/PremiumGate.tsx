import React from 'react';
import { Lock, Sparkles, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useSubscription, PremiumFeature } from '@/contexts/SubscriptionContext';

interface PremiumGateProps {
  feature: PremiumFeature;
  /** Display name of the feature, e.g. "Email Vigilante" */
  featureName: string;
  /** Tagline shown in the lock card */
  description: string;
  /** Required tier label, e.g. "Pro" */
  requiredTierLabel?: string;
  /** Anchor id forwarded to wrapper so scroll-to still works */
  anchorId?: string;
  children: React.ReactNode;
}

/**
 * Wraps a section with a paywall overlay when the user's tier is too low.
 * If the user already has access, renders the children directly.
 */
const PremiumGate: React.FC<PremiumGateProps> = ({
  feature,
  featureName,
  description,
  requiredTierLabel = 'Pro',
  anchorId,
  children,
}) => {
  const { hasFeature, tier } = useSubscription();
  const unlocked = hasFeature(feature);

  if (unlocked) {
    return <>{children}</>;
  }

  return (
    <section id={anchorId} className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-violet-50 via-white to-purple-50">
      <div className="max-w-4xl mx-auto">
        <div className="relative rounded-3xl border-2 border-violet-200 bg-white shadow-xl overflow-hidden">
          {/* Decorative blur */}
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-gradient-to-br from-violet-300 to-purple-300 rounded-full blur-3xl opacity-40 pointer-events-none" />
          <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-gradient-to-br from-pink-300 to-rose-300 rounded-full blur-3xl opacity-30 pointer-events-none" />

          <div className="relative p-8 sm:p-12 text-center">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-violet-100 text-violet-700 text-xs font-bold uppercase tracking-wide mb-5">
              <Sparkles className="w-3.5 h-3.5" />
              {requiredTierLabel} Feature
            </div>

            <div className="inline-flex w-20 h-20 items-center justify-center rounded-3xl bg-gradient-to-br from-violet-600 to-purple-700 text-white mb-6 shadow-lg">
              <Lock className="w-10 h-10" />
            </div>

            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-3">
              {featureName}
            </h2>
            <p className="text-lg text-gray-600 max-w-xl mx-auto mb-2">{description}</p>
            <p className="text-sm text-gray-500 mb-8">
              You're on the <span className="font-semibold capitalize">{tier}</span> plan. Upgrade to <span className="font-semibold text-violet-700">{requiredTierLabel}</span> to unlock this guardian.
            </p>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link
                to="/pricing"
                className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 text-white font-bold hover:from-violet-700 hover:to-purple-700 shadow-lg hover:shadow-xl transition-all"
              >
                Upgrade to {requiredTierLabel}
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/pricing"
                className="inline-flex items-center justify-center px-7 py-3.5 rounded-xl border-2 border-violet-200 text-violet-700 font-bold hover:bg-violet-50"
              >
                Compare plans
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export const PremiumBadge: React.FC<{ tier?: 'Pro' | 'Family'; className?: string }> = ({
  tier = 'Pro',
  className = '',
}) => (
  <span
    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide ${
      tier === 'Family'
        ? 'bg-pink-100 text-pink-700 border border-pink-200'
        : 'bg-violet-100 text-violet-700 border border-violet-200'
    } ${className}`}
  >
    <Sparkles className="w-3 h-3" />
    {tier}
  </span>
);

export default PremiumGate;
